Bia — Trial Version
Hello There!

Thank you for trying Bia.

This is a trial version for personal use only.
Commercial use requires a valid license.

For the full version and licensing:
bykineks.com

Questions or feedback:
bykineks@gmail.com

Bia

A transitional type system for expressive display typography.

Bia is a transitional type system designed for expressive display typography, exploring the balance between classical form, contemporary proportions, and typographic contrast.

Built as a unified system of four contrasting classifications—Serif Low, Serif High, Sans Low, and Sans High—Bia offers distinct visual voices within a shared typographic structure.

With five weights and five widths, the system moves from condensed and restrained forms to expansive and expressive compositions, making it suitable for headlines, logotypes, editorial covers, branding, packaging, and visual identities.

What's Included?

The trial version includes a limited selection of the Bia type system.

The full family includes 200 fonts across four classifications:

Serif Low
Serif High
Sans Low
Sans High

Each classification is available in:

5 Weights
Light, Regular, Medium, Semi Bold, Bold

5 Widths
Ultra Condensed, Condensed, Normal, Expanded, Ultra Expanded

2 Styles
Roman, Italic

Key Features
Transitional type system
Four contrasting classifications
Five weights
Five widths
Roman and Italic styles
Unified typographic structure
Classical and contemporary proportions
Expressive typographic contrast
Display-focused design
Branding and identity
Editorial applications
Packaging and campaigns
OpenType features
Stylistic alternates
Standard ligatures
Multilingual support
Recommended Usage
Display

24 pt+

Headlines, logotypes, posters, campaigns, editorial covers, packaging, and visual identities.

Large Display

48 pt+

Hero typography, art direction, advertising, title sequences, and expressive compositions.

Branding

Logotypes, brand identities, packaging, campaigns, and other applications where typography becomes a strong visual element.

Designed by

Dede Kurniawan

Published by

Bykineks

Published

2023

Version

2.100

Classification

Transitional

Fonts

200

Glyphs

1,037

Website

bykineks.com

Email

bykineks@gmail.com

Thank you for supporting independent type design.

© Bykineks Studio. All Rights Reserved.