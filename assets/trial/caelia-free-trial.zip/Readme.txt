Caelia — Trial Version

Hello There!

Thank you for trying Caelia.

This is a trial version for personal use only.
Commercial use requires a valid license.

For the full version and licensing:
bykineks.com

Questions or feedback:
bykineks@gmail.com


Caelia

Gothic Sans with a sharp architectural character.

Caelia is a Gothic Sans typeface shaped by the sharp and monumental character of Gothic architecture.

Its forms combine the functional structure of Gothic Sans with pointed geometry, sharp terminals, strong verticality, and sculptural proportions drawn from Gothic architectural details.

The result is a contemporary typeface with a distinctive balance of strength, elegance, and architectural character.

Designed for expressive typography, Caelia works across branding, identity, editorial, posters, packaging, and display applications.


What's Included?

The trial version includes a limited selection of the Caelia family.

The full family includes 5 styles:
Light, Regular, Medium, SemiBold, Bold


Key Features

Gothic Sans design
Sharp architectural character
Pointed geometry
Sharp terminals
Strong verticality
Sculptural proportions
OpenType features
Standard ligatures
Multilingual support


Language Support

Caelia supports a wide range of Latin, Cyrillic, and Greek-based languages, including:

Belarusian, Bosnian, Bulgarian, Chechen, Macedonian, Ossetic,
Russian, Serbian, Ukrainian, Uzbek, Greek, Afrikaans, Akan,
Albanian, Asturian, Asu, Bafia, Basque, Bemba, Bena, Breton,
Catalan, Chiga, Colognian, Cornish, Croatian, Czech, Danish,
Dutch, English, Esperanto, Estonian, Faroese, Filipino, Finnish,
French, German, Hungarian, Icelandic, Indonesian, Italian,
Maltese, Norwegian, Polish, Portuguese, Romanian, Slovak,
Slovenian, Spanish, Swahili, Swedish, Turkish, Ukrainian,
Vietnamese, Welsh, Yoruba, Zulu, and many more.


Designed by

Dede Kurniawan

Published by

Bykineks

Website
bykineks.com

Email
bykineks@gmail.com


Thank you for supporting independent type design.

© Bykineks Studio. All Rights Reserved.