Kineks Compact — Trial Version

Hello There!

Thank you for trying Kineks Compact.

This is a trial version for personal use only.
Commercial use requires a valid license.

For the full version and licensing:
bykineks.com

Questions or feedback:
bykineks@gmail.com


Kineks Compact

More information. Less space.

Kineks Compact is a neo-grotesque sans typeface designed for space-efficient digital interfaces, compact displays, and information-dense environments.

Developed from the DNA of Kineks Text, Kineks Compact features compact proportions, controlled spacing, and clear letterforms designed to maintain legibility within limited space.


What's Included?

The trial version includes a limited selection of the Kineks Compact family.

The full family includes 10 styles:
Light, Regular, Medium, SemiBold, Bold
Light Oblique, Regular Oblique, Medium Oblique, SemiBold Oblique, Bold Oblique


Key Features

Neo-grotesque design
Compact proportions
Designed for digital interfaces
Space-efficient typography
Clear small-size legibility
OpenType features
Stylistic alternates
Standard ligatures
Multilingual support


Recommended Usage

Small Text
8–10 pt
Labels, notifications, metadata, navigation, and compact interfaces.

Text
10–16 pt
Web interfaces, dashboards, documentation, and digital applications.

Large Text
16 pt+
Headings, interface titles, and larger text applications.


Designed by

Dede Kurniawan

Published by

Bykineks

Website
bykineks.com

Email
bykineks@gmail.com


Thank you for supporting independent type design.

© Bykineks Studio. All Rights Reserved.