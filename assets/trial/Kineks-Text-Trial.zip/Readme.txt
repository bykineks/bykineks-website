Kineks Text — Trial Version

Hello There!

Thank you for trying Kineks Text.

This is a trial version for personal use only.
Commercial use requires a valid license.

For the full version and licensing:
bykineks.com

Questions or feedback:
bykineks@gmail.com


Kineks Text

Same DNA. Different purpose.

Kineks Text is a neo-grotesque sans typeface designed for comfortable reading across editorial, digital, and everyday communication.

Developed from the DNA of Kineks Display, Kineks Text features refined proportions, spacing, rhythm, and details for text sizes.


What's Included?

The trial version includes a limited selection of the Kineks Text family.

The full family includes 10 styles:
Light, Regular, Medium, SemiBold, Bold
Light Oblique, Regular Oblique, Medium Oblique, SemiBold Oblique, Bold Oblique


Key Features

Neo-grotesque design
Designed for text reading
Balanced proportions
OpenType features
Stylistic alternates
Standard ligatures
Multilingual support


Recommended Usage

10–12 pt
Captions, labels, metadata, and compact interfaces.

12–18 pt
Websites, articles, documentation, and editorial content.

18 pt+
Subheadings, introductions, and larger text.


Designed by

Dede Kurniawan

Published by

Bykineks

Website
bykineks.com

Email
bykineks@gmail.com


Thank you for supporting independent type design.

© Bykineks Studio. All Rights Reserved.