Kineks — Trial Version
Hello There!
Thank you for trying Kineks.
This is a trial version for personal use only.
Commercial use requires a valid license.
For the full version and licensing:
bykineks.com
Questions or feedback:
hello@bykineks.com
Kineks
One system. Three voices.
Kineks is a contemporary type superfamily designed as a flexible typographic system for branding, editorial, digital products, and visual communication.
Built across Sans, Serif, and Slab, Kineks brings three distinct typographic voices together through a shared structure, consistent proportions, and a unified design language.
Rooted in neo-grotesque principles, Kineks combines clarity, versatility, and refined details across both functional and expressive applications.    Readme
What's Included?
The trial version includes a limited selection of the Kineks superfamily.
The full Kineks family includes 90 styles across:
Sans
Serif
Slab
with an extensive range of weights, widths, and italics.    Readme
Key Features
Neo-grotesque foundation
Sans, Serif, and Slab
90 styles in the full family
Multiple weights and widths
Italic styles
OpenType features
Stylistic alternates
Standard ligatures
90+ language support
Designed for print and digital use
Recommended Usage
Brand Identity
Logotypes, campaigns, identity systems, and visual communication.
Editorial
Magazines, publications, books, reports, and long-form layouts.
Digital
Websites, interfaces, applications, and digital products.
Display
Headlines, posters, advertising, packaging, and large-scale typography.
Designed by
Dede Kurniawan
Published by
BYKINEKS
Website
bykineks.com
Email
hello@bykineks.com
Thank you for trying Kineks.
© BYKINEKS Studio. All Rights Reserved.